# Semantic HTML5 & Accessible Component Architecture

A multi-page enterprise dashboard created for the RABTECH Academy task.

## Included
- Semantic HTML5 landmarks: `header`, `nav`, `main`, `section`, `article`, `aside`, `footer`
- Accessible navigation and skip link
- Accessible forms with `label`, `fieldset`, `legend`, descriptions and validation
- Accessible data tables with captions and scoped headers
- Native modal dialog
- Keyboard-visible focus states
- Responsive CSS Grid/Flexbox layout
- Multiple pages under `components/`

## Files
- `index.html` - main dashboard
- `components/forms.html` - accessible form components
- `components/tables.html` - accessible table component
- `styles.css` - responsive styling
- `script.js` - modal, navigation and form validation

## Validation
Validate each HTML page with the W3C Markup Validation Service before submission and fix any validator errors.
