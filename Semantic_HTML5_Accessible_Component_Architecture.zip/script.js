document.addEventListener("DOMContentLoaded", () => {
  const dialog = document.getElementById("reportDialog");
  const openModal = document.getElementById("openModal");
  const dialogFormLink = document.getElementById("dialogFormLink");
  const form = document.getElementById("reviewForm");
  const message = document.getElementById("formMessage");
  const menuButton = document.getElementById("menuButton");
  const sidebar = document.getElementById("sidebar");

  openModal?.addEventListener("click", () => dialog?.showModal());

  dialogFormLink?.addEventListener("click", () => dialog?.close());

  menuButton?.addEventListener("click", () => {
    const expanded = menuButton.getAttribute("aria-expanded") === "true";
    menuButton.setAttribute("aria-expanded", String(!expanded));
    sidebar.hidden = expanded;
  });

  form?.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!form.checkValidity()) {
      message.textContent = "Please complete all required fields correctly.";
      form.reportValidity();
      return;
    }
    message.textContent = "Accessibility review created successfully.";
    form.reset();
  });
});
